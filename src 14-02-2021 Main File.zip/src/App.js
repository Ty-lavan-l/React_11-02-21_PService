import LoginRegister from './components/forms/userform/UserFormik';
import WelcomePage from './components/home/Home';
import MainRouting from './components/router/MainRouting';

function App() {
  return (
    <div className="App">
      {/* <WelcomePage/> */}
      <MainRouting/>
      {/* <LoginRegister/> */}
    </div>
  );
}

export default App;
