import React, { useState } from "react";
import "./AdminFormik.css";
import { useSpring, animated } from "react-spring";
import {
  BrowserRouter as Router,
  NavLink
} from "react-router-dom";

function Basic() {
  const [registrationFormStatus, setRegistartionFormStatus] = useState(false);
  const loginProps = useSpring({ 
    left: registrationFormStatus ? -500 : 0, // Login form sliding positions
  });


  const loginBtnProps = useSpring({
    borderBottom: registrationFormStatus 
      ? "solid 0px transparent"
      : "solid 2px #1059FF",  //Animate bottom border of login button
  });


  function loginClicked() {
    setRegistartionFormStatus(false);
  }

  return (
    <div>
    <div className="login-register-wrapper">
      <div className="nav-buttons">
        <animated.button
          onClick={loginClicked}
          id="loginBtn"
          style={loginBtnProps}
        >
          Login
        </animated.button>

      </div>
      <div className="form-group">
        <animated.form action="" id="loginform" style={loginProps}>
          <LoginForm />
        </animated.form>
      </div>
    </div>
    </div>

  );
}

function LoginForm() {
  return (
    <React.Fragment>
      <label for="username">USERNAME</label>
      <input type="text" id="username" />
      <label for="password">PASSWORD</label>
      <input type="text" id="password" />
      <NavLink to="/userportal" style={{ textDecoration: 'none', color :'black' }}><input type="submit" value="submit" className="submit" /></NavLink>
    </React.Fragment>
  );
}
export default Basic;