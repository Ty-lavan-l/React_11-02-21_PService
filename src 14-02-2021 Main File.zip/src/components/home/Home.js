import React, { Component } from 'react'
import './Home.css'

export default class WelcomePage extends Component {
    render() {
        return (
            <div className="welcomePage">
                {/* Home Page Styling goes here */}
            </div>
        )
    }
}
