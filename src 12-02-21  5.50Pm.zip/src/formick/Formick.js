import React from 'react';
 import { Formik } from 'formik';
 
import {
  BrowserRouter as Router,
  Link,
  NavLink
} from "react-router-dom";

 
 const Basic = () => (
   <div>
     <br></br>
     <br></br>
     <Formik
       initialValues={{ email: '', password: '' }}
       validate={values => {
         const errors = {};
         if (!values.email) {
           errors.email = 'Required';
         } else if (
           !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
         ) {
           errors.email = 'Invalid email address';
         }
         return errors;
       }}
       onSubmit={(values, { setSubmitting }) => {
         setTimeout(() => {
           alert(JSON.stringify(values, null, 2));
           setSubmitting(false);
         }, 400);
       }}
     >
       {({
         values,
         errors,
         touched,
         handleChange,
         handleBlur,
         handleSubmit,
         isSubmitting,
         /* and other goodies */
       }) => (
         <form onSubmit={handleSubmit}>
                 <label htmlFor="emailid" style={{display : 'flex', justifyContent: "start", marginBottom:"7px"}}>Email Id :</label>
           <input
             type="email"
             name="emailid"
             onChange={handleChange}
             onBlur={handleBlur}
             placeholder="Email"
            //  value={values.email}
           />
           {errors.email && touched.email && errors.email}
           <br></br>
           <br></br>

           <label htmlFor="passwordid" style={{display : 'flex', justifyContent: "start",  marginBottom:"7px"}}>Password :</label>
           <input
             type="password"
             name="passwordid"
             placeholder="password"
             onChange={handleChange}
             onBlur={handleBlur}
            //  value={values.password}
           />
           {errors.password && touched.password && errors.password}
           <br></br>
           <br></br>



           <NavLink exact activeClassName="inneruserdetails" to="/inneruserdetails">          
           <button style={{border:"solid" ,backgroundColor:" rgba(19,38,79,1)", height:" 50px",width : "80px", borderRadius:" 12px", padding: "5px", fontSize:"18px"}}>Login</button>
           
           </NavLink>
            </form>
       )}
     </Formik>
   </div>
 );
 export default Basic;