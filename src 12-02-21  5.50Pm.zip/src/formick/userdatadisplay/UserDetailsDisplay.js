import React from "react";
import { Segment, Grid, Header, Divider, Image } from "semantic-ui-react";


class Hello extends React.Component {
  render() {
    return (
      <Grid container textAlign="center" style={{ marginTop: "50px" }}>
        {/* <Icon name="chevron left">BACK</Icon> */}
        <Segment
          style={{ minWidth: "1000px", minHeight: "500px", width: "1000px" }}
          textAlign="left"
        >
          <Image
            className="profile-image"
            src="https://image.freepik.com/free-vector/abstract-logo-with-colorful-leaves_1025-695.jpg"
            circular
            size="small"
          />
          <Header as="h1" textAlign="center" floated="left">
            USER EMPLOYEE DETAILS
          </Header>
          <Grid container columns={2}>
            <Grid.Column>
              <Grid container>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      EMP ID
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>TY10567</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      EMPLOYEE NAME
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>LAVAN</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      GENDER
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>MALE</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      CONTACT NUMBER
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>8951010764</b>
                  </Grid.Column>
                  
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      ALTERNATE CONTACT NUMBER
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>9611994168</b>
                  </Grid.Column>
                  </Grid.Row>
                  <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      OFFICIAL MAIL
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>lavan@testyantra.com</b>
                  </Grid.Column>
                  </Grid.Row>
                  <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      PERSONAL MAIL
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>lavan@gmail.com</b>
                  </Grid.Column>
                  </Grid.Row>
                  <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      YEAR OF PASSOUT
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>2019</b>
                  </Grid.Column>
                  </Grid.Row>
                  <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      {" "}
                      HIGHER QUALIFICATION
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>B.E M.TECH</b>
                  </Grid.Column>
                  </Grid.Row>

              </Grid>
            </Grid.Column>
            <Grid.Column>
              <Grid container>
              <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      DATE OF JOINING
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>04.01.2021</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      EXPIRIENCE
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>1.8</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      SKILLS ON FRONEND
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>HTML, CSS, JS, REACT JS</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      SKILLS ON BACKEND
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>JAVA</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      PERMANENT ADDRESS
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>Rpc Layout Vijayanagar Bangalore</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      TEMPORARY ADDRESS
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>Chandra  Layout Bangalore</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      CITY   
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>Bangalore</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      STATE   
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>Karnataka</b>
                  </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={2}>
                  <Grid.Column style={{ textAlign: "right" }}>
                    <Header as="h4" color="orange">
                      PINCODE   
                    </Header>
                  </Grid.Column>
                  <Grid.Column>
                    <b>540040</b>
                  </Grid.Column>
                </Grid.Row>
                
              </Grid>
            </Grid.Column>
          </Grid>
          <Divider className="api-divider" />
          <Grid container>
       
          </Grid>
        </Segment>
      </Grid>
    );
  }
}
export default Hello;