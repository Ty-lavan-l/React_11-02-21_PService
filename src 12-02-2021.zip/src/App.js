import './App.css';
import BasicExample from './components/EmployeeFinalLink';
import reduxForm from './formDel/MaterialUiForm';


function App() {
  return (
    <div className="App">
      <>
      {/* <reduxForm/> */}
      <BasicExample/>

      </>
    </div>
  );
}

export default App;
