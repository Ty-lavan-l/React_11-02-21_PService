import React from 'react';
import clsx from 'clsx';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import PersonIcon from '@material-ui/icons/Person';
import FeedbackIcon from '@material-ui/icons/Feedback';
import EmployeeForm from './feedback/pages/Employees/EmployeeForm';
import InnerEmployeeForm from '../formick/InnerEmployeeForm';
import EmployeeList from './dummydata/EmployeeList';
import MockFeedBackList from './dummydata2/EmployeeList';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Link,
  NavLink
} from "react-router-dom";
import { Button } from '@material-ui/core';

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
    
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    // padding: theme.spacing(1),
  },
  drawerPaper: {
    width: drawerWidth,
  },
  drawerContainer: {
    overflow: 'auto',
  },
  title: {
    flexGrow: 1,
  },
}));

export default function InnerAdminDetails() {
  const classes = useStyles();
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  

  return (
    <div className={classes.root}>
      <Router>
      <CssBaseline />
      <AppBar
      style={{ backgroundColor: 'rgba(19,38,79,1)' }}
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        })}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, {
              [classes.hide]: open,
            })}
          >
            <MenuIcon />
          </IconButton>
          <Typography style={{marginLeft:-20}} variant="h6" >
          <h2><a href="/home"  style={{ textDecoration: 'none' }}>PService</a></h2>         
           </Typography>


           <Typography className={classes} variant="h6" style={{paddingLeft:'25px'}} >
           <NavLink exact activeClassName="/employeeform" style={{ textDecoration: 'none' }} to="/employeeform">  
            EmployeeForm
            </NavLink>           </Typography>
           <Typography className={classes} variant="h6" style={{paddingLeft:'25px'}}>
           <NavLink exact activeClassName="/employeeform" style={{ textDecoration: 'none' }} to="/mockfeedback">  
            MockFeedbackForm
            </NavLink>          </Typography>

            <Typography className={classes.title}>   </Typography>
          <Typography className={classes.title}>   </Typography>
          <Typography className={classes.title}>   </Typography>
          <Typography className={classes.title}>   </Typography>
          <Typography className={classes.title}>   </Typography>
          <Typography className={classes.title}>   </Typography>
         <Typography className={classes.title} variant="h6">
         <a href="/home"   style={{marginLeft: 500 , textDecoration:"none"}} exact to="/">Logout</a>          </Typography>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
      >
        <div className={classes.toolbar}>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
          </IconButton>
        </div>
        <Divider />
        <List>
        <Link to="/employeeslist" style={{ textDecoration: 'none' }}>
  <List>
{['Employee Details'].map((text) => (
             <ListItem >
              <ListItemIcon>{<PersonIcon />}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItem>
             ))}
            </List>
        </Link>
        <Divider />

        </List>
        <List>
        <Link to="/feedbacklist" style={{ textDecoration: 'none' }}>
         <List>
    {[`Mock Reviews`].map((text) => (
             <ListItem>
              <ListItemIcon>{ <FeedbackIcon />}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItem>
             ))}
            </List>
        </Link>
        </List>
        <Divider />

      </Drawer>
      <main className={classes.content}>
        <Toolbar />
        <Switch>
          <Route path="/employeeslist">
            <EmployeeList/>
          </Route>
          <Route path="/feedbacklist">
          <MockFeedBackList/>
          </Route>
          <Route path="/employeeform">
          <InnerEmployeeForm/>
          </Route>
          <Route path="/mockfeedback">
          <EmployeeForm/>
          </Route>

        </Switch>
      </main>
      </Router>
    </div>
  
  );
}
