import React, { Component } from "react";
import myjson from "./data.json";
import "./Employee.css";

export default class MockFeedBackList extends Component {
  render() {
    return (
      <div className="table_main">
        <div>
          <h2>Test Yantra Development Unit-Mock Details</h2>
          <table className="table table-hover">
            <thead>
              <tr>
                <th><pre>   Employee Id</pre></th>
                <th><pre>        Name</pre></th>
                <th><pre>    Moke Date</pre></th>
                <th><pre> Mock Taken By</pre></th>
                <th><pre> Technologyes</pre></th>
                <th> Practical Score</th>
                <th>Theoritical Score</th>
                <th>Overall Feedback</th>
                <th>Action Taken</th>
                <th>DetailFeedback</th>
              </tr>
            </thead>
            <tbody>
              {myjson.map((emp) => (
                <tr key={emp.empid}>                  
                  <td>{emp.empid}</td>
                  <td>{emp.MockTakenBY}</td>
                  <td>{emp.Mockdate}</td>
                  <td>{emp.MockTakenBY}</td>
                  <td><pre>     {emp.Technology}</pre></td>
                  <td>{emp.PracticalScore}</td>
                  <td>{emp.TheoriticalScore}</td>
                  <td>{emp.OverallFeedback}</td>
                  <td>{emp.ActionItem}</td>
                  <td><pre>      {emp.Detailedfeedback}  </pre></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}