import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import LoginRegister from "../forms/userform/UserFormik";
// import  FormPropsTextFields from './Login&Register'
// import PrimarySearchAppBar from "./Navbar"
import MenuAppBar from '../navbar/Navbar'
import Home from "../home/Home"
import AdminLogin from "../forms/AdminForm/AdminFormik";
import MiniDrawer from "../navbar/AdminNavbar";
import UserNavbar from "../navbar/UserNavbar";
import AdminNavbar from "../navbar/AdminNavbar";
import EmployeeForm from "../admindetails/feedbackform/pages/EmployeeForm";
// import InnerAdminDetails from "./InnerAdminDetails";
// import InnerUserDetails from "./InnerUserDetails";
// import EmployeeForm from "./feedback/pages/Employees/EmployeeForm";

export default function MainRouting() {
  return (
    <Router>
      <div>

        <Switch>
          <Route exact path="/">
          <MenuAppBar/>
            <Home/>
          </Route>

          <Route path="/user">
          <MenuAppBar/>
          <LoginRegister/>
          </Route>
      
          <Route path="/admin">
          <MenuAppBar/>
          <AdminLogin/>
          </Route>


              
          <Route path="/userportal">
          <UserNavbar/>
          
          </Route>

          <Route path="/adminportal">
          <AdminNavbar/>

          </Route>

          <Route path="/userform">
          <EmployeeForm/>

          </Route>


          {/* <Route path="/inneruserdetails" component={InnerUserDetails}>
          </Route>
          <Route path="/employeeForm" component={InnerAdminDetails}>
          </Route> */}
        
        </Switch>
      </div>
    </Router>
  );
}

