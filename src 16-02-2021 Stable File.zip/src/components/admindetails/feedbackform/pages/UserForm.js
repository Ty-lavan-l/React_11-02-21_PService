
import React, { useState, useEffect } from 'react'
import Controls from "../../feedbackform/assets/controls/Controls";
import { useForm, Form } from "../../feedbackform/assets/useForm";
import  * as employeeService from "../../feedbackform/services/employeeService";
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { Container, TextField } from '@material-ui/core';
import './EmployeeForm.css'


const genderItems = [
    { id: 'male', title: 'Male' },
    { id: 'female', title: 'Female' },
    { id: 'other', title: 'Other' },
]

const initialFValues = {
    id: '',
    fullName: '',
    offemail:'',
    email: '',
    contactNumber: '',
    altContactNumber: '',
    yop:'',
    hqualification:'',
    doj:new Date(),
    exp:'',
    skillsF:'',
    skillsB:'',
    city: '',
    gender: 'male',
    pincode:'',
    state:'',
    paddress:'',
    taddress:'',
}

export default function UserEmployeeDetails() {

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "This field is required."
            if ('hqualification' in fieldValues)
            temp.hqualification = fieldValues.hqualification ? "" : "This field is required."
            if ('skillsF' in fieldValues)
            temp.skillsF = fieldValues.skillsF ? "" : "This field is required."
            if ('skillsB' in fieldValues)
            temp.skillsB = fieldValues.skillsB ? "" : "This field is required."
            if ('yop' in fieldValues)
            temp.yop = fieldValues.yop ? "" : "This field is required."
        if ('email' in fieldValues)
            temp.email = (/$^|.+@.+..+/).test(fieldValues.email) ? "" : "Email is not valid."
            else temp.email = fieldValues.email ? "" : "Email is required"
        if ('contactNumber' in fieldValues)
            temp.contactNumber = fieldValues.contactNumber.length > 9 ? "" : "Minimum 10 numbers required."
            if ('pincode' in fieldValues)
            temp. pincode = fieldValues. pincode.length > 6 ? "" : "Minimum 6 numbers required."
            if ('paddress' in fieldValues)
            temp.paddress = fieldValues.paddress ?  "" : "Address is required."
        if ('id' in fieldValues)
            temp.id = fieldValues.id.length != 0 ? "" : "This field is required."
        setErrors({
            ...temp
        })

        if (fieldValues === values)
            return Object.values(temp).every(x => x === "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
    }

    return (
        <Container maxWidth="md">
        <Card>
            <CardContent>
        
        <Form onSubmit={handleSubmit}>
            <h1>Enter Employee Details</h1>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={6}>
                <Controls.Input
                        name="id"
                        label="Employee ID"
                        value={values.id}
                        onChange={handleInputChange}
                        error={errors.id}
                    />
                    <Controls.Input
                        name="fullName"
                        label="Full Name"
                        value={values.fullName}
                        onChange={handleInputChange}
                        error={errors.fullName}
                    />
                    {/* <Grid align="left">       Hello             </Grid> */}

                     <Controls.RadioGroup
                        name="gender"
                        label="Gender"
                        value={values.gender}
                        onChange={handleInputChange}
                        items={genderItems}
                    />
                     <Controls.Input
                        label="Contact Number"
                        name="contactNumber"
                        value={values.contactNumber}
                        onChange={handleInputChange}
                        error={errors.contactNumber}
                    />
                     <Controls.Input
                        label="Alternate Contact Number"
                        name="altContactNumber"
                        value={values.mobile}
                        onChange={handleInputChange}
                        error={errors.mobile}
                    />
                    <Controls.Input
                        label="Official Email"
                        name="email"
                        value={values.email}
                        onChange={handleInputChange}
                        error={errors.email}
                    />
                    <Controls.Input
                        label="Personal Email"
                        name="offemail"
                        value={values.offemail}
                        onChange={handleInputChange}
                        error={errors.offemail}
                    />
                   
                   
                     <Controls.Input
                        label="Year Of Passout"
                        name="yop"
                        value={values.yop}
                        onChange={handleInputChange}
                        error={errors.yop}
                    />
                         <Controls.Input
                        label="Highest Qualification"
                        name="hqualification"
                        value={values.hqualification}
                        onChange={handleInputChange}
                        error={errors.hqualification}
                    />
                                       <form>

                    </form>
                </Grid>
                
                <Grid item xs={6}>
                <TextField
                    id="date"
                    label="Date of Joining"
                    type="date"
                    InputLabelProps={{   
                    shrink: true,
                     }}
                     />


                <Controls.Input
                        label="Exprience"
                        name="exp"
                        value={values.exp}
                        onChange={handleInputChange}
                        error={errors.exp}
                    />
                     <Controls.Input
                        label="Skills On FrontEnd Technology"
                        name="skillsF"
                        value={values.skillsF}
                        onChange={handleInputChange}
                        error={errors.skillsF}
                    />
                     <Controls.Input
                        label="Skills On BackEnd Technology"
                        name="skillsB"
                        value={values.skillsB}
                        onChange={handleInputChange}
                        error={errors.skillsB}
                    />
                      <Controls.Input
                        label="Permanent Address"
                        name="paddress"
                        value={values.paddress}
                        onChange={handleInputChange}
                        error={errors.paddress}
                    />
                    
                    <Controls.Input
                        label="Temporary Address"
                        name="taddress"
                        value={values.taddress}
                        onChange={handleInputChange}
                    />
                    
                    <Controls.Input
                        label="City"
                        name="city"
                        value={values.city}
                        onChange={handleInputChange}
                    />   
                    
                    
                    <Controls.Input
                        label="State"
                        name="state"
                        value={values.state}
                        onChange={handleInputChange}
                    />
                    
                    <Controls.Input
                        label="Pincode"
                        name="pincode"
                        value={values.pincode}
                        onChange={handleInputChange}
                        error={errors.pincode}
                    />
                    <div style={{display: 'flex', justifyContent : "flex-end"}}> 
                    <button  style={{border:"solid" , height:" 50px",width : "80px", borderRadius:" 12px", padding: "5px", fontSize:"18px"}}>Submit</button>
                    <button type="reset" onClick={resetForm}  style={{border:"solid" , height:" 50px",width : "80px", borderRadius:" 12px", padding: "5px", fontSize:"18px"}}>Reset</button>

                    </div>

                </Grid>
            </Grid>
        </Form>
        </CardContent>
        </Card>
        </Container>
        
    )
}
