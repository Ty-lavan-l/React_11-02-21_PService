import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { useTheme } from '@material-ui/core/styles';
import { Grid, } from '@material-ui/core';
import Controls from "../assets/controls/Controls";
import { useForm, Form } from '../assets/useForm';
import * as employeeService from "../services/employeeService";
import './EmployeeForm.css'


const initialFValues = {
    empid: '',
    fullName: '',
    mockdate: new Date(),
    mocktakenby: '',
    technology: '',
    therotical: '',
    pratical: '',
    overall: '',
    detailedfeedback:'',
   
}

export default function EmployeeForm() {

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "Pleasr provide fullname."
        if ('empid' in fieldValues)
            temp.empid = (/[0-9]+/).test(fieldValues.empid) ? "" : "Employee-id is not valid."
        if ('theortical' in fieldValues)
            temp.theortical = fieldValues.theortical.length < 4 ? "" : "Should have proper rating."
        if ('overall' in fieldValues)
            temp.overall = fieldValues.overall.length != 0 ? "" : "Please select overall rating."
            if ('detailedfeedback' in fieldValues)
            temp.detailedfeedback = fieldValues.detailedfeedback.length <300 ? "" : "Please keep character count below 300."
        setErrors({
            ...temp
        })

        if (fieldValues == values)
            return Object.values(temp).every(x => x == "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);


  const [open, setOpen] = React.useState(false);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  const handleClickOpen = () => {
      if(validate()){
        
    setOpen(true);
      }
  };

  const handleClose = () => {
    setOpen(false);
  };


    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
        handleClickOpen();
    }

    return (
        <div className="demo">
        <Form onSubmit={handleSubmit}>
            <Grid container justify="center">
                <Grid item xs={6}>                    
                <Controls.Input
                        name="empid"
                        label="Employee ID"
                        value={values.empid}
                        onChange={handleInputChange}
                        error={errors.empid}
                    /> 
                    
                     <Controls.Input
                        name="fullName"
                        label="Full Name"
                        value={values.fullName || ''}
                        onChange={handleInputChange}
                        error={errors.fullName}
                    /> 
                    <Controls.DatePicker
                        name="mockdate"
                        label="Mock Date"
                        value={values.mockdate}
                        onChange={handleInputChange}
                    />
                    
                    <Controls.Input
                        label="Mock taken By"
                        name="mocktakenby"
                        value={values.mocktakenby}
                        onChange={handleInputChange}
                        error={errors.mocktakenby}
                    />
                    <Controls.Input
                        label="Technology"
                        name="technology"
                        value={values.technology}
                        onChange={handleInputChange}
                        error={errors.technology}
                    />
                    <Controls.Input
                        label="Therotical rating (out of 100)"
                        name="therotical"
                        value={values.therotical}
                        onChange={handleInputChange}
                    />
                    
                     <Controls.Input
                        label="Praticle rating (out of 100)"
                        name="pratical"
                        value={values.pratical}
                        onChange={handleInputChange}
                    />
    
                    <Controls.Select
                        name="overall"
                        label="Overall Rating"
                        value={values.overall}
                        onChange={handleInputChange}
                        options={employeeService.getDepartmentCollection()}
                        error={errors.overall}
                    />
                    <Controls.Input
                        label="Detailed Feedback"
                        name="detailedfeedback"
                        value={values.detailedfeedback}
                        onChange={handleInputChange}
                        error={errors.detailedfeedback}
                    />
                    <div m={1} >
                        <Controls.Button
                            type="submit"
                            text="Submit" />
                           <Controls.Button
                            text="Reset"
                            color="default"
                            onClick={resetForm} />
                       </div>
                </Grid>
            </Grid>
        </Form>

                <Dialog
                fullScreen={fullScreen}
                open={open}
                onClose={handleClose}
                aria-labelledby="responsive-dialog-title"
                >
                <DialogTitle id="responsive-dialog-title">{"Employee Mock Feedback Form"}</DialogTitle>
                <DialogContent>
                <DialogContentText>
                Mock Feedback added successfully 
                </DialogContentText>
                </DialogContent>
                <DialogActions>
                <Button onClick={handleClose} color="primary" autoFocus>
                    ok
                </Button>
                </DialogActions>
                </Dialog>
                </div>


    )
}
