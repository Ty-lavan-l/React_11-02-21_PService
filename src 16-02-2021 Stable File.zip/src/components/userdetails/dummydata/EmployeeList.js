import React, { Component } from "react";
import myjson from "./data.json";
import "./Employee.css";
import { JsonToCsv, useJsonToCsv } from "react-json-csv";
import { Button } from "@material-ui/core";

function EmpToCSV() {
  const filename = "TY-Development-Employee Details",
    fields = {
      empid: "Employee ID",
      FullName: "Full Name",
      Gender: "Gender",
      ContactNum: "ContactNum",
      AlternateNum: "AlternateNum",
      Officilemail: "Officilemail",
      Personelemail: "Personelemail",
      Yearofpass: "Yearofpass",
      Stream: "Stream",
      Higherqualify: "Higherqualify",
      Dateofjoin: "Dateofjoin",
      Expirience: "Expirience",
      Skillonfrondend: "Skillonfrondend",
      Skillonbackend: "Skillonbackend",
      Permanentaddress: "Permanentaddress",
      Tempaddress: "Tempaddress",
      City: "City",
      State: "State",
      Pincode: "Pincode",
    },
    style = {
      padding: "5px",
    },

    data = myjson,
    text = "Convert Json to Csv";

  <JsonToCsv
    data={data}
    filename={filename}
    fields={fields}
    style={style}
    text={text}
  />;

  const { saveAsCsv } = useJsonToCsv();


  return (
    <div>
      <button className='myButton' onClick={(e) => saveAsCsv({ data, fields, filename })}>Download As Excel</button>
    </div>
  );
}

export default class EmployeeList extends Component {
  render() {
    return (
      <div className="table_main">
        <div>
          

          <h1 style={{display:'flex', justifyContent:'center'}}>Test Yantra Development Unit-Employee Details</h1>
          <table className="table table-hover">
            <thead class="thead-dark">
              <tr>
                <th>Employee ID</th>
                <th>Full Name</th>
                <th>Gender</th>
                <th>Contact Number</th>
                <th>Alternate Number</th>
                <th>Officil Mail ID</th>
                <th>Personel Mail ID</th>
                <th>Year Of Passout</th>
                <th>Stream</th>
                <th>Higher Qualification</th>
                <th>Date Of Join</th>
                <th>Expirience</th>
                <th>Skill On Frontend</th>
                <th>Skill On Backend</th>
                <th>Permanent Address</th>
                <th>Temporary Address</th>
                <th>City</th>
                <th>State</th>
                <th>Pincode</th>
              </tr>
            </thead>
            <tbody>
              {myjson.map((emp) => (
                <tr key={emp.empid}>
                  <td>{emp.empid}</td>
                  <td>{emp.FullName}</td>
                  <td>{emp.Gender}</td>
                  <td>{emp.ContactNum}</td>
                  <td>{emp.AlternateNum}</td>
                  {/* <td>{emp.EmergencyNum1}</td>
                  <td>{emp.EmergencyNum2}</td> */}
                  <td>{emp.Officilemail}</td>
                  <td>{emp.Personelemail}</td>
                  <td>{emp.Yearofpass}</td>
                  <td>{emp.Stream}</td>
                  <td>{emp.Higherqualify}</td>
                  <td>{emp.Dateofjoin}</td>
                  <td>{emp.Expirience}</td>
                  <td>{emp.Skillonfrondend}</td>
                  <td>{emp.Skillonbackend}</td>
                  <td>{emp.Permanentaddress}</td>
                  <td>{emp.Tempaddress}</td>
                  <td>{emp.City}</td>
                  <td>{emp.State}</td>
                  <td>{emp.Pincode}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <br></br>
        <EmpToCSV />
      </div>
    );
  }
}

