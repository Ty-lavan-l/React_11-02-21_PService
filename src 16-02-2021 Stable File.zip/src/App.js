import MockFeedBackList from './components/admindetails/dummydata2/EmployeeList';
import EmployeeForm from './components/admindetails/feedbackform/pages/EmployeeForm';
import UserEmployeeDetails from './components/admindetails/feedbackform/pages/UserForm';
import MainRouting from './components/router/MainRouting';

function App() {
  return (
    <div className="App">
      <MainRouting/>
      {/* <EmployeeForm/> */}
      {/* <UserEmployeeDetails/> */}
      {/* <MockFeedBackList/> */}
    </div>
  );
}

export default App;
