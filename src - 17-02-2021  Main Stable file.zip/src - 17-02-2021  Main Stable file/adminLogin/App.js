import React from 'react';
import './App22.css';
import SignInOutContainer from './containers';
function AdminLogin() {
  return (
    <div className="App">
     <SignInOutContainer/> 
    </div>
  );
} 

export default AdminLogin;
