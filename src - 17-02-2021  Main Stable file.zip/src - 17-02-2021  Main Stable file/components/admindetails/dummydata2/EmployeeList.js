import axios from "axios";
import React, { Component } from "react";
import myjson from "./data.json";
import "./Employee.css";
import { JsonToCsv, useJsonToCsv } from "react-json-csv";

function EmpToCSV() {
  const filename = "TY-Development-Mock Details",
    fields = {
      empid: "Employee ID",
      FullName: "Mock taken by",
      Mockdate: "Mock Date",
      MockTakenBY: "Mock Taken By",
      Technology: "Technology Known",
      PracticalScore: "Practical Score",
      TheoriticalScore: "Theoritical Score",
      OverallFeedback: "Overall Feedback",
      ActionItem: "Action Feedback",
      Detailedfeedback: "Detailed Feedback",
    },
    style = {
      padding: "5px",
    },
    data = myjson,
    text = "Convert Json to Csv";

  <JsonToCsv
    data={data}
    filename={filename}
    fields={fields}
    style={style}
    text={text}
  />;

  const { saveAsCsv } = useJsonToCsv();


  return (
    <div style={{display:'flex' , justifyItems:'right'}}>
      <button  className='myButton' onClick={(e) => saveAsCsv({ data, fields, filename })}>
        Download As Excel
      </button>
    </div>
  );
}

export default class MockFeedBackList extends Component {
    render() {
      return (
        <div className='demo'>
        <div className="table_main">
          <div>
            <h2 style={{display:'flex', justifyContent:'center'}}>Test Yantra Development Unit-Mock Details</h2>
            <table className="table table-hover">
              <thead>
                <tr>
                  <th><pre>Employee Id</pre></th>
                  <th><pre>Name</pre></th>
                  <th><pre>Moke Date</pre></th>
                  <th><pre>Mock Taken By</pre></th>
                  <th><pre>Technologyes</pre></th>
                  <th><pre>Practical
                     Score</pre></th>
                  <th>Theoritical Score</th>
                  <th>Overall Feedback</th>
                  <th> <pre>  Action Taken</pre></th>
                  <th><pre>                     DetailFeedback</pre></th>
                </tr>
              </thead>
              <tbody>
                {myjson.map((emp) => (
                  <tr key={emp.empid}>

                    <td>{emp.empid}</td>
                    <td>{emp.FullName}</td>
                    <td>{emp.Mockdate}</td>
                    <td>{emp.MockTakenBY}</td>
                    <td><pre>{emp.Technology}</pre></td>
                    <td>{emp.PracticalScore}</td>
                    <td>{emp.TheoriticalScore}</td>
                    <td>{emp.OverallFeedback}</td>
                    <td>{emp.ActionItem}</td>
                    <td><pre>{emp.Detailedfeedback}  </pre></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <br></br>
        <EmpToCSV />
          </div>
        </div>
        </div>
      );
    }
  }