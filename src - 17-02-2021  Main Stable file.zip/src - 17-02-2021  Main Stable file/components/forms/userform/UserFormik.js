import React from 'react'
import SigninSignup from '../../../signIn/App'

export default function LoginAndReg() {
  return (
    <div>
      <SigninSignup/>
    </div>
  )
}
