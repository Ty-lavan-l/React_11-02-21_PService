import React from 'react'
import SigninSignup from '../../../signIn/App'

export default function Signip() {
  return (
    <div>
      <SigninSignup/>
    </div>
  )
}
