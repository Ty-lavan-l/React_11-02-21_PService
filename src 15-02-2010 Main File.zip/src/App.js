import MainRouting from './components/router/MainRouting';

function App() {
  return (
    <div className="App">
      <MainRouting/>
    </div>
  );
}

export default App;
